<form method="post" action="<?php echo site_url('auth/login') ?>">
<label>Kode Admin</label><br>
<input type="text" name="kd_admin" value=""><p></p>
<label>Password</label><br>
<input type="password" name="pswd_admin" value=""><p></p>
<input type="submit" value="Login">
</form>